<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="An awesome single page template. You can
  design your website by using this ">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <!-- vendors file-->
  <link rel="stylesheet" type="text/css" href="vendors/css/normalize.css">
  <link rel="stylesheet" type="text/css" href="vendors/css/vendor.css">

  <!-- Resource File-->
  <link rel="stylesheet" type="text/css" href="resource/css/style.css">
  <link rel="stylesheet" type="text/css" href="Resource/css/responsive.css">
  <!-- Google FOnt-->
  <link href="https://fonts.googleapis.com/css2?family=Titillium+Web:wght@300;400;600;700&display=swap" rel="stylesheet">
  <!-- Font Awesome-->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.13.0/css/all.css" integrity="sha384-Bfad6CLCknfcloXFOyFnlgtENryhrpZCe29RTifKEixXQZ38WheV+i/6YWSzkz3V" crossorigin="anonymous">

  <title>Cuda- Practiced by Mamun</title>
  <link rel="shortcut icon" type="image/x-icon" href="resource/img/icon.png">
</head>
<body>
  <!-- header start-->
  <header id="home">
    <nav id="navbar">
      <div class="row">
        <a href="#">
          <img src="resource/img/logo.png" alt="cuda logo" class="logo">
        </a>
        <ul class="main-nav">
          <li class="active"><a href="#home">Home</a></li>
          <li><a href="#service">service</a></li>
          <li><a href="#team">team</a></li>
          <li><a href="#skill">skill</a></li>
          <li><a href="#port">portfolio</a></li>
          <li><a href="#about">testimonial</a></li>
          <li><a href="#contact">contact</a></li>
        </ul>
        <div class="mobile-menu">
          <span onclick="openNav()" style="color: #fff;">&#9776;</span>
          <div class="overlay" id="myNav">
            <a href="javascript:void(0)" onclick="closeNav()" class="close-btn">&times;</a>
            <div class="overlay-content">
              <a onclick="closeNav()" href="#home">Home</a>
              <a onclick="closeNav()" href="#service">service</a>
              <a onclick="closeNav()" href="#team">team</a>
              <a onclick="closeNav()" href="#skill">skill</a>
              <a onclick="closeNav()" href="#port">portfolio</a>
              <a onclick="closeNav()" href="#about">testimonial</a>
              <a onclick="closeNav()" href="#contact">contact</a>
            </div>
          </div>
        </div>
      </div>
    </nav>
    <div class="row">
      <div class="hero-text">
        <h1>Hi there! We are the new kids on the block
        and we build awesome websites and mobile apps.</h1>
        <a href="#contact" class="btn_1">Work with Us</a>

      </div>
    </div>
  </header>
  <!-- header end-->
  <!-- services start-->
<section class="service_sec js-service-sec" id="service">
  <div class="row">
    <h2>SERVICES WE PROVIDE</h2>
    <p class="little_description">We are working with both individuals and businesses from all over the globe
    to create awesome websites and applications.</p>
  </div>
  <div class="row">
    <div class="col span_1_of_4 box">
      <img src="resource/img/flag.png" alt="Flag" class="service_icon">
      <h3>BRANDING</h3>
      <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh.</p>
    </div>
    <div class="col span_1_of_4 box">
      <img src="resource/img/pencil.png" alt="Pencil" class="service_icon">
      <h3>DESIGN</h3>
      <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem.</p>
    </div>
    <div class="col span_1_of_4 box">
      <img src="resource/img/gears.png" alt="gears" class="service_icon">
      <h3>DEVELOPMENT</h3>
      <p>At vero eos et accusamus et iusto odio dignissimos qui blanditiis praesentium.</p>
    </div>
    <div class="col span_1_of_4 box">
      <img src="resource/img/rocket.png" alt="rocket" class="service_icon">
      <h3>Rocket SCIENCE</h3>
      <p>Et harum quidem rerum est et expedita distinctio. Nam libero tempore.</p>
    </div>
  </div>
</section>

  <!-- services end  -->

 <!--team start -->
<section class="team_sec" id="team">
  <div class="row">
    <h2>MEET OUR BEAUTIFUL TEAM</h2>
    <p class="little_description">We are a small team of designers and developers, who help brands with big ideas.</p>
  </div>
  <div class="row">
    <div class="col span_1_of_4 box">
      <img src="resource/img/steven-smith-1053.png" alt="Smith" class="team_img">
      <h3>Steve Smith</h3>
      <span class="under_name">Very talented Player</span>
      <p class="box_team">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt
      ut laoreet dolore magna.</p>
      <div class="social-link">
        <ul>
          <li><a href="https://www.facebook.com/mamun.abdullah.275/"><i class="fab fa-facebook-f"></i></a></li>
          <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
          <li><a href="#"><i class="fab fa-twitter"></i></a></li>
          <li><a href="#"><i class="fas fa-envelope"></i></a></li>
        </ul>
      </div>
    </div>
    <div class="col span_1_of_4 box">
      <img src="resource/img/kohli.png" alt="kohli" class="team_img">
      <h3>virat kohli</h3>
      <span class="under_name">Classic batsman in 3 format</span>
      <p>Duis aute irure dolor in in voluptate velit esse cillum dolore fugiat nulla pariatur. Excepteur
      sint occaecat non diam proident.</p>
      <div class="social-link">
        <ul>
          <li><a href="https://www.facebook.com/mamun.abdullah.275/"><i class="fab fa-facebook-f"></i></a></li>
          <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
          <li><a href="#"><i class="fab fa-twitter"></i></a></li>
          <li><a href="#"><i class="fas fa-envelope"></i></a></li>
        </ul>
      </div>
    </div>
    <div class="col span_1_of_4 box">
      <img src="resource/img/dhoni.png" alt="Dhoni" class="team_img">
      <h3>MS dhoni</h3>
      <span class="under_name">Captain Cool </span>
      <p class="box_team">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt
      ut laoreet dolore magna.</p>
      <div class="social-link">
        <ul>
          <li><a href="https://www.facebook.com/mamun.abdullah.275/"><i class="fab fa-facebook-f"></i></a></li>
          <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
          <li><a href="#"><i class="fab fa-twitter"></i></a></li>
          <li><a href="#"><i class="fas fa-envelope"></i></a></li>
        </ul>
      </div>
    </div>
    <div class="col span_1_of_4 box">
      <img src="resource/img/michael-clarke-521.png" alt="clarke" class="team_img">
      <h3>Michael Clarke</h3>
      <span class="under_name">Classic test Batsman </span>

      <p class="box_team">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt
      ut laoreet dolore magna.</p>
      <div class="social-link">
        <ul>
          <li><a href="https://www.facebook.com/mamun.abdullah.275/"><i class="fab fa-facebook-f"></i></a></li>
          <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
          <li><a href="#"><i class="fab fa-twitter"></i></a></li>
          <li><a href="#"><i class="fas fa-envelope"></i></a></li>
        </ul>
      </div>
    </div>
  </div>


</section>

<!-- team end  -->

<!--skill start -->
<section class="skill_sec" id="skill">
  <div class="row">
    <h2>WE GOT SKILLS!</h2>
    <p class="little_description">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
    tempor incididunt ut labore et dolore magna aliqua.</p>
  </div>
  <div class="row">
    <div class="col span_1_of_4 box">
      <svg class="radial-progress web-design" data-percentage="90" viewBox="0 0 80 80">
        <circle class="incomplete" cx="40" cy="40" r="35"></circle>
        <circle class="complete" cx="40" cy="40" r="35" style="stroke-dashoffset: 39.58406743523136;"></circle>
        <text class="percentage" x="50%" y="57%" transform="matrix(0, 1, -1, 0, 80, 0)">90%</text>
      </svg>
      <h3>WEB design</h3>
    </div>
    <div class="col span_1_of_4 box">
      <svg class="radial-progress html_css" data-percentage="70" viewBox="0 0 80 80">
        <circle class="incomplete" cx="40" cy="40" r="35"></circle>
        <circle class="complete" cx="40" cy="40" r="35" style="stroke-dashoffset: 39.58406743523136;"></circle>
        <text class="percentage" x="50%" y="57%" transform="matrix(0, 1, -1, 0, 80, 0)">75%</text>
      </svg>
      <h3>html/css</h3>
    </div>
    <div class="col span_1_of_4 box">
      <svg class="radial-progress graphic-design" data-percentage="70" viewBox="0 0 80 80">
        <circle class="incomplete" cx="40" cy="40" r="35"></circle>
        <circle class="complete" cx="40" cy="40" r="35" style="stroke-dashoffset: 39.58406743523136;"></circle>
        <text class="percentage" x="50%" y="57%" transform="matrix(0, 1, -1, 0, 80, 0)">70%</text>
      </svg>
      <h3>graphic design</h3>
    </div>
    <div class="col span_1_of_4 box">
      <svg class="radial-progress ui-ux" data-percentage="85" viewBox="0 0 80 80">
        <circle class="incomplete" cx="40" cy="40" r="35"></circle>
        <circle class="complete" cx="40" cy="40" r="35" style="stroke-dashoffset: 39.58406743523136;"></circle>
        <text class="percentage" x="50%" y="57%" transform="matrix(0, 1, -1, 0, 80, 0)">85%</text>
      </svg>
      <h3>ui/ux</h3>
    </div>
    </div>

</section>
<!-- skill end  -->

<!--portfolio start -->
<section class="portfolio-sec" id="port">
  <div class="row">
    <h2>OUR PORTFOLIO</h2>
    <p class="little_description">Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet
    consectetur, adipisci velit, sed quia non numquam</p>
  </div>
  <div class="row port-button">
    <button type="button" data-filter="all">all</button>
    <button type="button" data-filter=".web">web</button>
    <button type="button" data-filter=".apps">apps</button>
    <button type="button" data-filter=".icon">icon</button>

  </div>
  <div class="row container">
    <div class="col span_1_of_2 mix apps box">
      <img src="resource/img/port1.png" alt="Isometric Perspective Mock-Up" class="portfolio-img">
      <h4>Isometric Perspective Mock-Up</h4>
    </div>
    <div class="col span_1_of_2 mix apps web box">
      <img src="resource/img/port2.png" alt="Time Zone App UI" class="portfolio-img">
      <h4>Time Zone App UI</h4>
    </div>
    <div class="col span_1_of_2 mix box web icon port_3">
      <img src="resource/img/port3.png" alt="Viro Media Players UI" class="portfolio-img">
      <h4>Viro Media Players UI</h4>
    </div>
    <div class="col span_1_of_2 mix apps icon box">
      <img src="resource/img/port4.png" alt="Blog / Magazine Flat UI Kit" class="portfolio-img">
      <h4>Blog / Magazine Flat UI Kit</h4>
    </div>
  </div>
  <div class="row">
    <a href="#contact-with" class="btn_1 btn-load-more">load more project</a>
  </div>

</section>
<!--portfolio end -->
<!--about us start -->

<section class="about-sec" id="about">
  <div class="row">
    <h2>WHAT POEPLE SAY ABOUT US</h2>
    <p class="little_description">Our clients love us!</p>
  </div>
  <div class="row">
    <div class="col span_1_of_2 box">
      <div class="client-img">
        <img src="resource/img/a1.jpg" alt="iman" class="about-img">
      </div>
      <div class="client-review">
        <p>“Nullam dapibus blandit orci, viverra gravida dui lobortis eget. Maecenas fringilla urna eu ”</p>
        <h3>Chanel Iman</h3>
        <span class="role">CEO of Pinterest</span>
      </div>
    </div>
    <div class="col span_1_of_2 box">
      <div class="client-img">
        <img src="resource/img/a3.jpg" alt="lima" class="about-img">
      </div>
      <div class="client-review">
        <p>“Vivamus luctus urna sed urna ultricies ac tempor dui sagittis. In condimentum facilisis porta.”</p>
        <h3>ADRIANA LIMA</h3>
        <span class="role">Founder of Instagram</span>
      </div>
    </div>

    <div class="col span_1_of_2 box">
      <div class="client-img">
        <img src="resource/img/a4.jpg" alt="stone" class="about-img">
      </div>
      <div class="client-review">
        <p>“Phasellus non purus vel arcu tempor commodo. Fusce semper, purus vel luctus molestie, risus sem cursus neque.”</p>
        <h3>EMMA STONE</h3>
        <span class="role">Co-Founder of Shazam</span>
      </div>
    </div>

    <div class="col span_1_of_2 box">
      <div class="client-img">
        <img src="resource/img/a2.jpg" alt="anne" class="about-img">
      </div>
      <div class="client-review">
        <p>“Vivamus luctus urna sed urna ultricies ac tempor dui sagittis. In condimentum facilisis porta.”</p>
        <h3>ANNE HATHAWAY</h3>
        <span class="role">Lead Designer at Behance</span>
      </div>
    </div>
  </div>
</section>

<!--about us end -->
<!--get in touch start -->
<section class="contact-sec" id="contact">
  <div class="row">
    <h2>get in touch</h2>
    <p class="little_description">1600 Pennsylvania Ave NW, Washington, DC 20500, United States of America. Tel: (202) 456-1111</p>
  </div>
  <div class="row">
    <form action="https://formspree.io/mamunabdullah275@gmail.com" method="post">
     <div class="row">
       <div class="col span_1_of_2 box">
         <input type="text" name="Name" placeholder="Your Name *" required>
       </div>
       <div class="col span_1_of_2 box">
         <input type="email" name="email" placeholder="Your Mail *" required>
       </div>
     </div>
     <div class="row">
       <textarea name="Message" rows="5" cols="10" placeholder="Your Message *" required></textarea>
     </div>
     <div class="row">
       <input type="submit" value="send message" class="btn_1">
     </div>
   </form>
  </div>
</section>


<!--get in touch end -->
<!--footer end -->
  <section class="footer">
    <div class="row">
      <ul>
        <li><a href="#">Facebook</a></li>
        <li><a href="#">Twitter</a></li>
        <li><a href="#">Google+</a></li>
        <li><a href="#">LinkedIn</a></li>
        <li><a href="#">Behance</a></li>
        <li><a href="#">Dribbble</a></li>
        <li><a href="#">GitHub</a></li>
      </ul>
    </div>
  </section>
<!--footer end -->

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="vendors/js/html5shiv.min.js"></script>
  <script src="vendors/js/respond.min.js"></script>
  <script src="vendors/js/selectivizr-min.js"></script>
  <script src="vendors/js/jquery.waypoints.min.js"></script>
  <script src="vendors/js/mixitup.min.js"></script>
  <script src="resource/js/main.js"></script>

</body>
</html>
